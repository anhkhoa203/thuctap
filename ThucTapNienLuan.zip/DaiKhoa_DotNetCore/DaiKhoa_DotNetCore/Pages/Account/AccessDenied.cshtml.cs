using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DaiKhoa_DotNetCore.Pages
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
